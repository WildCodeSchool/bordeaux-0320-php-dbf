-- MySQL dump 10.13  Distrib 8.0.21, for osx10.14 (x86_64)
--
-- Host: 127.0.0.1    Database: dbfaudi
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `call`
--

DROP TABLE IF EXISTS `call`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `vehicle_id` int NOT NULL,
  `subject_id` int NOT NULL,
  `comment_id` int DEFAULT NULL,
  `service_id` int DEFAULT NULL,
  `recall_period_id` int NOT NULL,
  `recipient_id` int DEFAULT NULL,
  `author_id` int NOT NULL,
  `is_urgent` tinyint(1) NOT NULL,
  `is_process_ended` tinyint(1) DEFAULT NULL,
  `is_appointment_taken` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `recall_date` date NOT NULL,
  `recall_hour` time NOT NULL,
  `free_comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `internet` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_processed` tinyint(1) DEFAULT NULL,
  `appointment_date` date DEFAULT NULL,
  `client_callback` int NOT NULL,
  `origin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CC8E2F3E19EB6921` (`client_id`),
  KEY `IDX_CC8E2F3E545317D1` (`vehicle_id`),
  KEY `IDX_CC8E2F3E23EDC87` (`subject_id`),
  KEY `IDX_CC8E2F3EF8697D13` (`comment_id`),
  KEY `IDX_CC8E2F3EED5CA9E6` (`service_id`),
  KEY `IDX_CC8E2F3ED31619AD` (`recall_period_id`),
  KEY `IDX_CC8E2F3EE92F8F78` (`recipient_id`),
  KEY `IDX_CC8E2F3EF675F31B` (`author_id`),
  CONSTRAINT `FK_CC8E2F3E19EB6921` FOREIGN KEY (`client_id`) REFERENCES `client` (`id`),
  CONSTRAINT `FK_CC8E2F3E23EDC87` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`),
  CONSTRAINT `FK_CC8E2F3E545317D1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicle` (`id`),
  CONSTRAINT `FK_CC8E2F3ED31619AD` FOREIGN KEY (`recall_period_id`) REFERENCES `recall_period` (`id`),
  CONSTRAINT `FK_CC8E2F3EE92F8F78` FOREIGN KEY (`recipient_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_CC8E2F3EED5CA9E6` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`),
  CONSTRAINT `FK_CC8E2F3EF675F31B` FOREIGN KEY (`author_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_CC8E2F3EF8697D13` FOREIGN KEY (`comment_id`) REFERENCES `comment` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call`
--

LOCK TABLES `call` WRITE;
/*!40000 ALTER TABLE `call` DISABLE KEYS */;
INSERT INTO `call` VALUES (127,210,192,22,37,NULL,22,24,24,0,NULL,0,'2021-02-17 23:21:32','2021-02-17','08:00:00','aucun',NULL,NULL,1,NULL,0,NULL),(128,211,193,27,52,NULL,22,24,28,0,NULL,0,'2021-02-18 00:36:19','2021-02-19','14:00:00','<b>Rendez-vous souhaité à</b> : Bordeaux - La Teste<br><b>Commentaire laissé</b> : test',NULL,NULL,1,NULL,0,'fretd'),(129,212,194,23,44,NULL,22,30,28,0,NULL,NULL,'2021-02-18 00:37:24','2021-02-19','10:00:00','<b>Rendez-vous Atelier souhaité à</b> : Bordeaux - Mérignac<br><b>Origine de la demande</b> : <br><b>Commentaire laissé</b> : test',NULL,NULL,NULL,NULL,0,NULL),(130,213,195,48,52,NULL,22,24,28,0,NULL,NULL,'2021-02-18 00:38:21','2021-02-19','16:00:00','<b>Commentaire laissé</b> : message contact',NULL,NULL,NULL,NULL,0,NULL);
/*!40000 ALTER TABLE `call` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call_processing`
--

DROP TABLE IF EXISTS `call_processing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_processing` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contact_type_id` int NOT NULL,
  `refered_call_id` int NOT NULL,
  `created_at` datetime NOT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ACF3EAB15F63AD12` (`contact_type_id`),
  KEY `IDX_ACF3EAB1BE5DC693` (`refered_call_id`),
  CONSTRAINT `FK_ACF3EAB15F63AD12` FOREIGN KEY (`contact_type_id`) REFERENCES `contact_type` (`id`),
  CONSTRAINT `FK_ACF3EAB1BE5DC693` FOREIGN KEY (`refered_call_id`) REFERENCES `call` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call_processing`
--

LOCK TABLES `call_processing` WRITE;
/*!40000 ALTER TABLE `call_processing` DISABLE KEYS */;
INSERT INTO `call_processing` VALUES (64,26,127,'2021-02-17 23:22:28',NULL),(65,27,127,'2021-02-17 23:22:50',NULL),(66,26,128,'2021-02-18 09:16:06',NULL);
/*!40000 ALTER TABLE `call_processing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call_transfer`
--

DROP TABLE IF EXISTS `call_transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_transfer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `by_whom_id` int NOT NULL,
  `from_whom_id` int NOT NULL,
  `to_whom_id` int NOT NULL,
  `refered_call_id` int NOT NULL,
  `created_at` datetime NOT NULL,
  `comment_transfer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_1652C27A60D8982D` (`by_whom_id`),
  KEY `IDX_1652C27A9D748C23` (`from_whom_id`),
  KEY `IDX_1652C27A95B25279` (`to_whom_id`),
  KEY `IDX_1652C27ABE5DC693` (`refered_call_id`),
  CONSTRAINT `FK_1652C27A60D8982D` FOREIGN KEY (`by_whom_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_1652C27A95B25279` FOREIGN KEY (`to_whom_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_1652C27A9D748C23` FOREIGN KEY (`from_whom_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_1652C27ABE5DC693` FOREIGN KEY (`refered_call_id`) REFERENCES `call` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call_transfer`
--

LOCK TABLES `call_transfer` WRITE;
/*!40000 ALTER TABLE `call_transfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `call_transfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `city` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(155) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identifier` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` VALUES (17,'Bordeaux',NULL),(18,'Toulouse',NULL),(19,'Montpellier',NULL),(20,'Cellule Téléphonique','PHONECITY');
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city_head`
--

DROP TABLE IF EXISTS `city_head`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `city_head` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `city_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_44BDCBF4A76ED395` (`user_id`),
  KEY `IDX_44BDCBF48BAC62AF` (`city_id`),
  CONSTRAINT `FK_44BDCBF48BAC62AF` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`),
  CONSTRAINT `FK_44BDCBF4A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city_head`
--

LOCK TABLES `city_head` WRITE;
/*!40000 ALTER TABLE `city_head` DISABLE KEYS */;
/*!40000 ALTER TABLE `city_head` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `civility`
--

DROP TABLE IF EXISTS `civility`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `civility` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `civility`
--

LOCK TABLES `civility` WRITE;
/*!40000 ALTER TABLE `civility` DISABLE KEYS */;
INSERT INTO `civility` VALUES (13,'M.'),(14,'Mme'),(15,'Ste');
/*!40000 ALTER TABLE `civility` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client` (
  `id` int NOT NULL AUTO_INCREMENT,
  `civility_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C744045523D6A298` (`civility_id`),
  CONSTRAINT `FK_C744045523D6A298` FOREIGN KEY (`civility_id`) REFERENCES `civility` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=214 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (210,13,'vaillant','0859784578',NULL,NULL,'2021-02-17 23:21:32',NULL),(211,13,'LUDUC','0587457845',NULL,NULL,'2021-02-18 00:36:19',NULL),(212,13,'LANDING','0632154512',NULL,NULL,'2021-02-18 00:37:24',NULL),(213,13,'CONTACT','0784758454',NULL,NULL,'2021-02-18 00:38:21',NULL);
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identifier` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_hidden` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (37,'Rev 30000','r30',NULL),(38,'Rev 60000','r60',NULL),(39,'Rev 90000','r90',NULL),(40,'Rev 120000','r120',NULL),(41,'Rev 150000','r150',NULL),(42,'Freins','freins',NULL),(43,'Embrayage','embrayage',NULL),(44,'Pneus','pneus',NULL),(45,'Distribution','distribution',NULL),(49,'MECANIQUE - INTERNET','MECANIQUEINTERNET',1),(50,'ENTRETIEN - INTERNET','ENTRETIENINTERNET',1),(51,'CAROSSERIE - INTERNET','CAROSSERIEINTERNET',1),(52,'INTERNET','INTERNET',1);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concession`
--

DROP TABLE IF EXISTS `concession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concession` (
  `id` int NOT NULL AUTO_INCREMENT,
  `town_id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postcode` int NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nearest_car_body_workshop_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B517BD9D75E23604` (`town_id`),
  KEY `IDX_B517BD9DEF5BEE12` (`nearest_car_body_workshop_id`),
  CONSTRAINT `FK_B517BD9D75E23604` FOREIGN KEY (`town_id`) REFERENCES `city` (`id`),
  CONSTRAINT `FK_B517BD9DEF5BEE12` FOREIGN KEY (`nearest_car_body_workshop_id`) REFERENCES `service` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concession`
--

LOCK TABLES `concession` WRITE;
/*!40000 ALTER TABLE `concession` DISABLE KEYS */;
INSERT INTO `concession` VALUES (49,20,'Cellule Téléphonique',' ',33000,' ','  ',' ',NULL),(50,17,'La Teste','70 Rue Lagrua',33260,'La Teste de Buch',' Audi','05 57 73 66 99',NULL),(51,17,'Mérignac','34 avenue Roland Garros',33700,'Mérignac','Audi','05 56 02 71 71',446),(52,17,'Artigues','9 Avenue du Millac',33370,'Artigues Près Bordeaux',' Audi','05 56 86 75 40',NULL),(53,18,'Etats-Unis','344 avenue des États-Unis Toulouse Nord • Sortie 33 B Sesquières Lalande',31201,'Toulouse Cedex 2','Volkswagen','05 62 75 87 58',NULL),(54,18,'Labège','2686, route de baziège',31670,'Labège','Volkswagen','05 61 36 30 00',NULL),(55,18,'Espagne','290 Rue Leon Joulin',31100,'Toulouse','Volkswagen','05 61 44 44 44',NULL),(56,19,'Saint Clément de Rivière','Impasse des églantiers',34980,'Saint Clément de Rivière','Audi et Volkswagen','04 67 61 02 94',NULL),(57,19,'Le Crès','145, route de Nîmes',34920,'Le Crès','Volkswagen','04 67 70 50 00',NULL),(58,19,'Sète','13, quai Louis Pasteur',34200,'Sète','Volkswagen','04 67 46 07 00',446),(59,19,'Tournezy VW','3160 Avenue de Maurin Tournezy',34076,'Montpellier Cedex 3','Volkswagen','04 67 07 83 83',NULL),(60,19,'Tournezy Audi','3160 Avenue de Maurin',34076,'Montpellier Cedex 3','Audi','04 67 07 83 93',NULL);
/*!40000 ALTER TABLE `concession` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concession_head`
--

DROP TABLE IF EXISTS `concession_head`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concession_head` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `concession_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_BC831C69A76ED395` (`user_id`),
  KEY `IDX_BC831C694132BB14` (`concession_id`),
  CONSTRAINT `FK_BC831C694132BB14` FOREIGN KEY (`concession_id`) REFERENCES `concession` (`id`),
  CONSTRAINT `FK_BC831C69A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concession_head`
--

LOCK TABLES `concession_head` WRITE;
/*!40000 ALTER TABLE `concession_head` DISABLE KEYS */;
/*!40000 ALTER TABLE `concession_head` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_type`
--

DROP TABLE IF EXISTS `contact_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identifier` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_type`
--

LOCK TABLES `contact_type` WRITE;
/*!40000 ALTER TABLE `contact_type` DISABLE KEYS */;
INSERT INTO `contact_type` VALUES (25,'Contact établi','contact'),(26,'Message 1','msg1'),(27,'Message 2','msg2'),(28,'Message 3','msg3'),(29,'Abandon','abandon'),(30,'Non éligible','nl');
/*!40000 ALTER TABLE `contact_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbf_contact`
--

DROP TABLE IF EXISTS `dbf_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dbf_contact` (
  `id` int NOT NULL AUTO_INCREMENT,
  `civility_id` int NOT NULL,
  `service_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `immat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `hour` int NOT NULL,
  `minute` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `IDX_2CE9A01923D6A298` (`civility_id`),
  KEY `IDX_2CE9A019ED5CA9E6` (`service_id`),
  CONSTRAINT `FK_2CE9A01923D6A298` FOREIGN KEY (`civility_id`) REFERENCES `civility` (`id`),
  CONSTRAINT `FK_2CE9A019ED5CA9E6` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbf_contact`
--

LOCK TABLES `dbf_contact` WRITE;
/*!40000 ALTER TABLE `dbf_contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbf_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migration_versions`
--

DROP TABLE IF EXISTS `migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migration_versions` (
  `version` varchar(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `executed_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migration_versions`
--

LOCK TABLES `migration_versions` WRITE;
/*!40000 ALTER TABLE `migration_versions` DISABLE KEYS */;
INSERT INTO `migration_versions` VALUES ('20200705135741','2020-07-15 08:20:39'),('20200706125634','2020-07-15 08:20:39'),('20200706125956','2020-07-15 08:20:39'),('20200713084025','2020-07-15 08:20:39'),('20200713123556','2020-07-15 08:20:39'),('20200714101425','2020-07-15 08:20:39'),('20200715163348','2020-07-15 16:33:54'),('20200716161605','2020-07-16 20:22:03'),('20200719073958','2020-07-19 07:40:06'),('20210210112754','2021-02-10 11:28:02'),('20210210150151','2021-02-10 15:01:57'),('20210210152854','2021-02-10 15:29:00'),('20210210161509','2021-02-10 16:15:20'),('20210211094645','2021-02-11 09:46:52'),('20210211182255','2021-02-11 18:23:06'),('20210216193728','2021-02-16 19:37:39');
/*!40000 ALTER TABLE `migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recall_period`
--

DROP TABLE IF EXISTS `recall_period`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recall_period` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identifier` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recall_period`
--

LOCK TABLES `recall_period` WRITE;
/*!40000 ALTER TABLE `recall_period` DISABLE KEYS */;
INSERT INTO `recall_period` VALUES (21,'Avant','avant'),(22,'Autour de','autourde'),(23,'après','apres'),(24,'dès que possible','desquepossible'),(25,'urgent','urgent');
/*!40000 ALTER TABLE `recall_period` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `right`
--

DROP TABLE IF EXISTS `right`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `right` (
  `id` int NOT NULL AUTO_INCREMENT,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `right`
--

LOCK TABLES `right` WRITE;
/*!40000 ALTER TABLE `right` DISABLE KEYS */;
INSERT INTO `right` VALUES (17,'admin'),(18,'director'),(19,'user'),(20,'intern');
/*!40000 ALTER TABLE `right` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `right_by_location`
--

DROP TABLE IF EXISTS `right_by_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `right_by_location` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `service_id` int DEFAULT NULL,
  `concession_id` int DEFAULT NULL,
  `city_id` int DEFAULT NULL,
  `authorization_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_5BF77D77A76ED395` (`user_id`),
  KEY `IDX_5BF77D77ED5CA9E6` (`service_id`),
  KEY `IDX_5BF77D774132BB14` (`concession_id`),
  KEY `IDX_5BF77D778BAC62AF` (`city_id`),
  KEY `IDX_5BF77D772F8B0EB2` (`authorization_id`),
  CONSTRAINT `FK_5BF77D772F8B0EB2` FOREIGN KEY (`authorization_id`) REFERENCES `right` (`id`),
  CONSTRAINT `FK_5BF77D774132BB14` FOREIGN KEY (`concession_id`) REFERENCES `concession` (`id`),
  CONSTRAINT `FK_5BF77D778BAC62AF` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`),
  CONSTRAINT `FK_5BF77D77A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_5BF77D77ED5CA9E6` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `right_by_location`
--

LOCK TABLES `right_by_location` WRITE;
/*!40000 ALTER TABLE `right_by_location` DISABLE KEYS */;
/*!40000 ALTER TABLE `right_by_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service` (
  `id` int NOT NULL AUTO_INCREMENT,
  `concession_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_car_body_workshop` tinyint(1) DEFAULT NULL,
  `is_direction` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E19D9AD24132BB14` (`concession_id`),
  CONSTRAINT `FK_E19D9AD24132BB14` FOREIGN KEY (`concession_id`) REFERENCES `concession` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=556 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` VALUES (445,50,'Mécanique','Audi',NULL,NULL),(446,50,'Carrosserie','Audi',1,0),(448,50,'Pièces détachées','Audi',NULL,NULL),(457,51,'Carrosserie','Audi',NULL,NULL),(458,51,'Financement','Audi',NULL,NULL),(459,51,'Pièces détachées','Audi',NULL,NULL),(460,51,'Marketing','Audi',NULL,NULL),(461,51,'Location Courte Durée (RENT)','Audi',NULL,NULL),(462,51,'Service Commercial Véhicules Neufs','Audi',NULL,NULL),(463,51,'Service Commercial Véhicules Occasions','Audi',NULL,NULL),(468,52,'Carrosserie','Audi',1,0),(469,52,'Financement','Audi',NULL,NULL),(470,52,'Pièces détachées','Audi',NULL,NULL),(471,52,'Marketing','Audi',NULL,NULL),(472,52,'Location Courte Durée (RENT)','Audi',NULL,NULL),(473,52,'Service Commercial Véhicules Neufs','Audi',NULL,NULL),(474,52,'Service Commercial Véhicules Occasions','Audi',NULL,NULL),(475,52,'Secrétariat Véhicules Neufs','Audi',NULL,NULL),(476,52,'Secrétariat Véhicules Occasions','Audi',NULL,NULL),(477,52,'Service Qualité','Audi',NULL,NULL),(478,53,'Mécanique','Volkswagen',NULL,NULL),(479,53,'Carrosserie','Volkswagen',NULL,NULL),(480,53,'Financement','Volkswagen',NULL,NULL),(481,53,'Pièces détachées','Volkswagen',NULL,NULL),(482,53,'Marketing','Volkswagen',NULL,NULL),(483,53,'Location Courte Durée (RENT)','Volkswagen',NULL,NULL),(484,53,'Service Commercial Véhicules Neufs','Volkswagen',NULL,NULL),(485,53,'Service Commercial Véhicules Occasions','Volkswagen',NULL,NULL),(486,53,'Secrétariat Véhicules Neufs','Volkswagen',NULL,NULL),(487,53,'Secrétariat Véhicules Occasions','Volkswagen',NULL,NULL),(488,53,'Service Qualité','Volkswagen',NULL,NULL),(489,54,'Mécanique','Volkswagen',NULL,NULL),(490,54,'Carrosserie','Volkswagen',NULL,NULL),(491,54,'Financement','Volkswagen',NULL,NULL),(492,54,'Pièces détachées','Volkswagen',NULL,NULL),(493,54,'Marketing','Volkswagen',NULL,NULL),(494,54,'Location Courte Durée (RENT)','Volkswagen',NULL,NULL),(495,54,'Service Commercial Véhicules Neufs','Volkswagen',NULL,NULL),(496,54,'Service Commercial Véhicules Occasions','Volkswagen',NULL,NULL),(497,54,'Secrétariat Véhicules Neufs','Volkswagen',NULL,NULL),(498,54,'Secrétariat Véhicules Occasions','Volkswagen',NULL,NULL),(499,54,'Service Qualité','Volkswagen',NULL,NULL),(500,55,'Mécanique','Volkswagen',NULL,NULL),(501,55,'Carrosserie','Volkswagen',NULL,NULL),(502,55,'Financement','Volkswagen',NULL,NULL),(503,55,'Pièces détachées','Volkswagen',NULL,NULL),(504,55,'Marketing','Volkswagen',NULL,NULL),(505,55,'Location Courte Durée (RENT)','Volkswagen',NULL,NULL),(506,55,'Service Commercial Véhicules Neufs','Volkswagen',NULL,NULL),(507,55,'Service Commercial Véhicules Occasions','Volkswagen',NULL,NULL),(508,55,'Secrétariat Véhicules Neufs','Volkswagen',NULL,NULL),(509,55,'Secrétariat Véhicules Occasions','Volkswagen',NULL,NULL),(510,55,'Service Qualité','Volkswagen',NULL,NULL),(511,56,'Mécanique','Audi',NULL,NULL),(512,56,'Carrosserie','Audi',NULL,NULL),(513,56,'Financement','Audi',NULL,NULL),(514,56,'Pièces détachées','Audi',NULL,NULL),(515,56,'Marketing','Audi',NULL,NULL),(516,56,'Location Courte Durée (RENT)','Audi',NULL,NULL),(517,56,'Service Commercial Véhicules Neufs','Audi',NULL,NULL),(518,56,'Service Commercial Véhicules Occasions','Audi',NULL,NULL),(519,56,'Secrétariat Véhicules Neufs','Audi',NULL,NULL),(520,56,'Secrétariat Véhicules Occasions','Audi',NULL,NULL),(521,56,'Service Qualité','Audi',NULL,NULL),(522,57,'Mécanique','Volkswagen',NULL,NULL),(523,57,'Carrosserie','Volkswagen',NULL,NULL),(524,57,'Financement','Volkswagen',NULL,NULL),(525,57,'Pièces détachées','Volkswagen',NULL,NULL),(526,57,'Marketing','Volkswagen',NULL,NULL),(527,57,'Location Courte Durée (RENT)','Volkswagen',NULL,NULL),(528,57,'Service Commercial Véhicules Neufs','Volkswagen',NULL,NULL),(529,57,'Service Commercial Véhicules Occasions','Volkswagen',NULL,NULL),(530,57,'Secrétariat Véhicules Neufs','Volkswagen',NULL,NULL),(531,57,'Secrétariat Véhicules Occasions','Volkswagen',NULL,NULL),(532,57,'Service Qualité','Volkswagen',NULL,NULL),(533,58,'Mécanique','Volkswagen',NULL,NULL),(534,58,'Carrosserie','Volkswagen',NULL,NULL),(535,58,'Financement','Volkswagen',NULL,NULL),(536,58,'Pièces détachées','Volkswagen',NULL,NULL),(537,58,'Marketing','Volkswagen',NULL,NULL),(538,58,'Location Courte Durée (RENT)','Volkswagen',NULL,NULL),(539,58,'Service Commercial Véhicules Neufs','Volkswagen',NULL,NULL),(540,58,'Service Commercial Véhicules Occasions','Volkswagen',NULL,NULL),(541,58,'Secrétariat Véhicules Neufs','Volkswagen',NULL,NULL),(542,58,'Secrétariat Véhicules Occasions','Volkswagen',NULL,NULL),(543,58,'Service Qualité','Volkswagen',NULL,NULL),(544,59,'Mécanique','Volkswagen',NULL,NULL),(545,59,'Carrosserie','Volkswagen',NULL,NULL),(546,59,'Financement','Volkswagen',NULL,NULL),(547,59,'Pièces détachées','Volkswagen',NULL,NULL),(548,59,'Marketing','Volkswagen',NULL,NULL),(549,59,'Location Courte Durée (RENT)','Volkswagen',NULL,NULL),(550,59,'Service Commercial Véhicules Neufs','Volkswagen',NULL,NULL),(551,59,'Service Commercial Véhicules Occasions','Volkswagen',NULL,NULL),(552,59,'Secrétariat Véhicules Neufs','Volkswagen',NULL,NULL),(553,59,'Secrétariat Véhicules Occasions','Volkswagen',NULL,NULL),(554,59,'Service Qualité','Volkswagen',NULL,NULL),(555,49,'Cellule téléphonique','Audi',NULL,NULL);
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_head`
--

DROP TABLE IF EXISTS `service_head`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_head` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `service_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_69B04270A76ED395` (`user_id`),
  KEY `IDX_69B04270ED5CA9E6` (`service_id`),
  CONSTRAINT `FK_69B04270A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_69B04270ED5CA9E6` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_head`
--

LOCK TABLES `service_head` WRITE;
/*!40000 ALTER TABLE `service_head` DISABLE KEYS */;
INSERT INTO `service_head` VALUES (57,24,446),(59,24,448),(60,25,445),(61,25,446),(63,25,448),(72,25,457),(73,25,458),(74,24,468);
/*!40000 ALTER TABLE `service_head` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject`
--

DROP TABLE IF EXISTS `subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subject` (
  `id` int NOT NULL AUTO_INCREMENT,
  `city_id` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_for_app_workshop` tinyint(1) NOT NULL,
  `is_hidden` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_FBCE3E7A8BAC62AF` (`city_id`),
  CONSTRAINT `FK_FBCE3E7A8BAC62AF` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject`
--

LOCK TABLES `subject` WRITE;
/*!40000 ALTER TABLE `subject` DISABLE KEYS */;
INSERT INTO `subject` VALUES (22,20,'Rendez-vous Atelier Artigues',1,NULL),(23,20,'Rendez-vous Atelier Mérignac',0,NULL),(24,20,'Rendez-vous Atelier La Teste',0,NULL),(25,20,'Rendez-vous Carrosserie Artigues',0,NULL),(26,17,'Rendez-vous Carrosserie Mérignac',0,NULL),(27,19,'Rendez-vous Carrosserie La Teste',1,0),(28,18,'Tarifs',0,NULL),(29,20,'Formulaire internet',1,1),(30,20,'Rendez-vous Carosserie La Teste',1,1),(31,20,'Formulaire de contact site DBF',1,1),(32,20,'Formulaire de contact site DBF',1,1),(33,20,'Formulaire de contact site DBF',1,1),(34,20,'Formulaire de contact site DBF',1,1),(35,20,'Formulaire de contact site DBF',1,1),(36,20,'Formulaire de contact site DBF',1,1),(37,20,'Formulaire de contact site DBF',1,1),(38,20,'Formulaire de contact site DBF',1,1),(39,20,'Formulaire de contact site DBF',1,1),(40,20,'Formulaire de contact site DBF',1,1),(41,20,'Formulaire de contact site DBF',1,1),(42,20,'Formulaire de contact site DBF',1,1),(43,20,'Formulaire de contact site DBF',1,1),(44,20,'Formulaire de contact site DBF',1,1),(45,20,'Formulaire de contact site DBF',1,1),(46,20,'Formulaire de contact site DBF',1,1),(47,20,'Formulaire de contact site DBF',1,1),(48,20,'Formulaire de contact site DBF',1,1);
/*!40000 ALTER TABLE `subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int DEFAULT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` json NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `civility_id` int DEFAULT NULL,
  `has_accepted_alert` tinyint(1) NOT NULL DEFAULT '1',
  `can_be_recipient` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`),
  KEY `IDX_8D93D649ED5CA9E6` (`service_id`),
  KEY `IDX_8D93D64923D6A298` (`civility_id`),
  CONSTRAINT `FK_8D93D64923D6A298` FOREIGN KEY (`civility_id`) REFERENCES `civility` (`id`),
  CONSTRAINT `FK_8D93D649ED5CA9E6` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (24,446,'frvaillant@gmail.com','[\"ROLE_ADMIN\"]','$argon2id$v=19$m=65536,t=4,p=1$/+tMsBGyKF59Si9lGjQSRg$eZg20e5srbz534Wh0Dg/xHIe8b5IETGcxuzma6YEA0I','François','VAILLANT',NULL,'2021-01-29 00:11:14','2021-02-17 23:20:00',NULL,1,1),(25,446,'michael.de-ruijter@dbf-autos.fr','[\"ROLE_ADMIN\"]','$argon2id$v=19$m=65536,t=4,p=1$Qty8EMuH23TpHiVJQoR4hg$duas4rnur29Xb2jvyA3M500Kv2K14rSucfR71jyrfRc','Michael','DE RUIJTER',NULL,'2021-01-29 00:11:14',NULL,NULL,1,0),(26,457,'francoisvaillant@free.fr','[\"ROLE_COLLABORATOR\"]','$argon2id$v=19$m=65536,t=4,p=1$xy74k3WV80UVdH2gR82fFA$EpBcvxHMP8AgdXFTUFEGVIxOT9A2jQ4A8kyVGLKq97o','DUVAL','Francis','0578451212','2021-02-10 10:11:10','2021-02-16 11:01:58',13,1,1),(28,555,'easyauto@dbf-autos.fr','[\"ROLE_COLLABORATOR\"]','1234','INTERNET','DBF AUTOS','0808080808','2021-02-11 11:47:38',NULL,13,0,0),(29,555,'truc@bid.com','[\"ROLE_COLLABORATOR\"]','$argon2id$v=19$m=65536,t=4,p=1$GDgi7MuFauKqVFt1Jr8+gQ$v7jYfCcO7fn8TOG6LYzqKkXCLlkfotN7+1kypkNJFeg','Sophie','DUTEIL',NULL,'2021-02-11 12:14:05','2021-02-16 11:01:45',14,1,1),(30,555,'lemon@frvaillant.com','[\"ROLE_COLLABORATOR\"]','$argon2id$v=19$m=65536,t=4,p=1$eM0qQN9WxTsBUy1ASeXqTA$3ax+n7HXEgI3keR9qo9E6dmthRfo0oswPatmjST2Fks','Alexia','JOVIAL',NULL,'2021-02-11 12:14:35','2021-02-11 12:21:53',14,1,1),(31,555,'rl@dbf.com','[\"ROLE_COLLABORATOR\"]','$argon2id$v=19$m=65536,t=4,p=1$+I2rZ1p3m4NVHOuBA87pyg$Zm6F+vlUu8GT/dvVollmGL3gXrE4Db/yl1jwYXA5uVQ','Roger','LAFONT',NULL,'2021-02-11 12:15:39',NULL,13,1,0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicle`
--

DROP TABLE IF EXISTS `vehicle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicle` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `immatriculation` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chassis` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `has_come` int NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_1B80E48619EB6921` (`client_id`),
  CONSTRAINT `FK_1B80E48619EB6921` FOREIGN KEY (`client_id`) REFERENCES `client` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicle`
--

LOCK TABLES `vehicle` WRITE;
/*!40000 ALTER TABLE `vehicle` DISABLE KEYS */;
INSERT INTO `vehicle` VALUES (192,210,'fgds45d',NULL,0,'2021-02-17 23:21:32',NULL),(193,211,'kjl45kl',NULL,0,'2021-02-18 00:36:19',NULL),(194,212,'jk4mo',NULL,0,'2021-02-18 00:37:24',NULL),(195,213,'hjk45df',NULL,0,'2021-02-18 00:38:21',NULL);
/*!40000 ALTER TABLE `vehicle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'dbfaudi'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-19  9:33:59
